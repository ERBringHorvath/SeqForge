# SPDX-License-Identifier: MIT
# Copyright (c) 2025 Elijah Bring Horvath

import os
import subprocess
import csv
import pandas as pd
from concurrent.futures import ProcessPoolExecutor
from itertools import islice
import re
from Bio import SeqIO
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from datetime import datetime
import logging

from .utils.file_handler import collect_fasta_files, cleanup_temp_dir
from .utils.progress import ProgressHandler

FASTA_EXTS = ('.fa', '.fna', '.fas', '.ffn', '.fasta', '.faa')

def chunkify(iterable, n):
    #Split iterable into chunks of size n for motif mining
    it = iter(iterable)
    return iter(lambda: list(islice(it, n)), [])

def export_motif_fasta(
        motif_df, 
        output_dir, 
        fasta_path=None, 
        motif_only=False, 
        temp_dir_base=None,
        keep_temp=False,
        logger=None
    ):
    if motif_df.empty:
        print("\033[93mNo motif matches to write FASTA files for.\033[0m")
        return

    fasta_records = {}
    genome_temp_dir = None

    if not motif_only and fasta_path:
        try:
            fasta_files, genome_temp_dir = collect_fasta_files(
                fasta_path, 
                temp_dir_base=temp_dir_base
            )
        except ValueError:
            fasta_files, genome_temp_dir = [], None

        for file in fasta_files:
            for record in SeqIO.parse(file, "fasta"):
                fasta_records[record.id] = str(record.seq).upper()

        cleanup_temp_dir(genome_temp_dir, keep=keep_temp, logger=logger)

    motif_cols = [col for col in motif_df.columns if col.startswith("motif_") and not col.endswith("_pattern")]

    for idx, motif_col in enumerate(motif_cols, start=1):
        pattern_col = f"motif_{idx}_pattern"
        motif_rows = motif_df[motif_col].dropna()
        motif_rows = motif_rows[motif_rows.str.strip() != ""]

        if motif_rows.empty:
            continue

        motif_pattern = motif_df[pattern_col].dropna().iloc[0]
        fasta_out = os.path.join(output_dir, f"{motif_pattern}_matches.faa")

        with open(fasta_out, "w") as f:
            for i, row in enumerate(motif_df.loc[motif_rows.index].itertuples(), start=1):
                header = f">{row.query}_{row.sstart}_{row.send}_hit{i}"

                if motif_only:
                    sequence = getattr(row, motif_col)
                else:
                    #Extract full BLAST-aligned region from the FASTA record
                    seq = fasta_records.get(row.sseqid)
                    if not seq:
                        continue
                    low, high = sorted([row.sstart, row.send])
                    sequence = seq[low - 1:high]  #1-based to 0-based adjustment

                f.write(f"{header}\n{sequence}\n")

        print(f"\033[92mWrote {len(motif_rows)} matches to {fasta_out}\033[0m")

def execute_blast_query(data):
    (blast, db_path, query_file_path, output_file, alignment_file,
     evalue_threshold, db_name, query_file_basename, min_seq_len,
     write_alignment) = data

    cmd_tabular = (
        f"{blast} -query {query_file_path} -db {db_path} "
        f"-outfmt '6 qseqid sseqid pident length mismatch gapopen qstart qend sstart send "
        f"evalue bitscore qlen sframe' "
        f"-out {output_file} -evalue {evalue_threshold}"
    )
    if min_seq_len:
        cmd_tabular += f" -task {blast}-short -dust no"

    result = subprocess.run(cmd_tabular, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"\033[91mBLAST failed:\033[0m {result.stderr}")

    if write_alignment:
        cmd_alignment = (
            f"{blast} -query {query_file_path} -db {db_path} "
            f"-outfmt 0 -out {alignment_file} -evalue {evalue_threshold}"
        )
        subprocess.run(cmd_alignment, shell=True)

    return output_file, db_name, query_file_basename

def search_motif_block(rows, fasta_records, motif_regexes):
    import os
    results, warnings = [], []

    for row in rows:
        gene_id = row['sseqid']
        genome = row['database']
        query_file = row['query_file_name']
        query_basename = os.path.splitext(query_file)[0]
        seq = fasta_records.get(gene_id)

        try:
            sstart, send = int(row['sstart']), int(row['send'])
        except (KeyError, ValueError) as e:
            warnings.append(f"Skipping row with invalid coords for {gene_id}: {e}")
            continue

        matches = [rid for rid in fasta_records if row['sseqid'] in rid]

        # if debug:
        #     print(f"Looking for {row['sseqid']} --> available keys matching: {matches}")

        #pull full sequence, then subsequence
        seq = next((s for rid, s in fasta_records.items()
                    if rid.startswith(gene_id)), None)

        if not seq:
            warnings.append(f"No FASTA record for {gene_id}")
            print(f"No FASTA record for sseqid: {gene_id}")
            continue

        low, high = sorted([sstart, send])
        subseq = seq[low-1:high]  # 1‑based → 0‑based slice

        #for each motif regex, emit one row PER match
        for idx, (motif_string, regex, target_basename) in enumerate(motif_regexes, start=1):
            #if user restricted motif to a particular query, skip others
            if target_basename and query_basename != target_basename:
                continue

            for m in regex.finditer(subseq):
                hit = {
                    'genome':   genome,
                    'query':    query_file,
                    'sseqid':   gene_id,
                    'sstart':   sstart,
                    'send':     send,
                    #record which motif and the pattern they used
                    f'motif_{idx}':         m.group(),
                    f'motif_{idx}_pattern': motif_string,
                    #absolute positions of the motif in the full seq
                    'match_start': low + m.start(),
                    'match_end':   low + m.end() - 1,
                }
                results.append(hit)

    return results, warnings

def run_motif_search(
        df, 
        fasta_path, 
        motif_regexes, 
        results_output_dir, 
        threads, 
        progress=None,
        keep_temp=False,
        temp_dir_base=None
    ):

    fasta_records = {}
    try:
        fasta_files, temp_dir = collect_fasta_files(
            fasta_path, temp_dir_base=temp_dir_base
        )
    except ValueError as e:
        print(f"\n\033[91mError: {e}\033[0m")
        return pd.DataFrame()
    
    for file in fasta_files:
        for record in SeqIO.parse(file, "fasta"):
            fasta_records[record.id] = str(record.seq).upper()
    
    cleanup_temp_dir(temp_dir, keep=keep_temp)

    #Parallel search
    rows = [row for _, row in df.iterrows()]
    row_chunks = list(chunkify(rows, max(1, len(rows) // max(1, threads))))

    results, warnings = [], []

    progress_mode = progress if progress is not None else "none"
    motif_progress = ProgressHandler(total=len(row_chunks), prefix="Motif Search", mode=progress_mode)

    with ProcessPoolExecutor(max_workers=threads) as executor:
        futures = [executor.submit(search_motif_block, chunk, fasta_records, motif_regexes)
                   for chunk in row_chunks]
        for future, chunk in zip(futures, row_chunks):
            res, warns = future.result()
            results.extend(res)
            warnings.extend(warns)
            motif_progress.update(1, current_item=f"chunk size {len(chunk)}")
        motif_progress.finish()

    #Log warnings once
    for w in warnings:
        print(f"\033[93m{w}\033[0m")

    if results:
        motif_df = pd.DataFrame(results)
        base_cols = ['genome', 'query', 'sseqid', 'sstart', 'send']

        #Ensure motif columns always exist
        for idx in range(1, len(motif_regexes) + 1):
            for col in (f"motif_{idx}", f"motif_{idx}_pattern"):
                if col not in motif_df.columns:
                    motif_df[col] = ''

        #No collapsing: keep one row per individual motif hit (including repeats)
        motif_cols = [c for idx in range(1, len(motif_regexes) + 1)
                    for c in (f"motif_{idx}", f"motif_{idx}_pattern")]
        motif_df = motif_df[base_cols + motif_cols + ['match_start', 'match_end']]

        motif_df.to_csv(os.path.join(results_output_dir, "motif_matches.csv"), index=False)
        print(f"\n\033[92mMotif matches saved to motif_matches.csv\033[0m")
    else:
        print("\n\033[91mNo motif matches found\033[0m")
        motif_df = pd.DataFrame()
    
    return motif_df

def run_multiblast(args):
    logger = logging.getLogger("query")
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if not any(isinstance(h, logging.FileHandler) and h.baseFilename.endswith("seqforge_query.log")
               for h in logger.handlers):
        file_handler = logging.FileHandler("seqforge_query.log", mode='a')
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    start_time = datetime.now()
    print(f"Query started at {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"Query started at {start_time.strftime('%Y-%m-%d %H:%M:%S')}")

    db_dir = args.database
    query_path = args.query_files
    fasta_path = args.fasta_directory
    results_output_dir = args.output
    threads = args.threads if args.threads else 4

    evalue_threshold = args.evalue if args.evalue is not None else 1e-5
    perc_identity_threshold = args.min_perc if args.min_perc is not None else 90
    query_coverage_threshold = args.min_cov if args.min_cov is not None else 75

    if not os.path.exists(results_output_dir):
        os.makedirs(results_output_dir)

    try:
        query_files, temp_dir = collect_fasta_files(query_path, temp_dir_base=args.temp_dir)
    except ValueError as e:
        print(f"\n\033[91mError: {e}\033[0m")
        logger.error(str(e))
        return
    
    if not query_files:
        print(f"\033[91mError: No valid FASTA file(s) found at {query_path}\033[0m")
        logger.warning("No valid FASTA files found")
        return

    db_basenames = set()
    if os.path.isdir(db_dir):
        for f in os.listdir(db_dir):
            if f.endswith(('.nhr', '.phr')):
                db_basenames.add(os.path.splitext(os.path.join(db_dir, f))[0])
    elif os.path.isfile(db_dir):
        if db_dir.endswith(('.nhr', '.phr')):
            db_basenames.add(os.path.splitext(db_dir)[0])
        else:
            print(f"\033[91mError: Provided database file must end in .nhr or .phr\033[0m")
            return
    elif os.path.exists(db_dir + ".nhr") or os.path.exists(db_dir + ".phr"):
        db_basenames.add(db_dir)
    else:
        print(f"\033[91mError: No valid BLAST database found at {db_dir}\033[0m")
        logger.warning(f"No valid BLAST database found at {db_dir}")
        return

    #Determine DB types
    db_type_map, detected_db_types = {}, set()
    for db_path in db_basenames:
        base = os.path.basename(db_path)
        if os.path.exists(db_path + ".nhr"):
            db_type = "nucleotide"
        elif os.path.exists(db_path + ".phr"):
            db_type = "protein"
        else:
            print(f"\033[93mWarning: No valid .nhr or .phr for {db_path}\033[0m")
            logger.warning(f"No valid DB index for {db_path}")
            continue
        db_type_map[base] = db_type
        detected_db_types.add(db_type)

    print(f"\033[95mDetected {', '.join(detected_db_types)} database(s)\033[0m")
    logger.info(f"Detected {', '.join(detected_db_types)} database(s)")

    #Validate and preprocess motifs
    motif_regexes, using_motif = [], False
    if args.motif:
        if "nucleotide" in detected_db_types:
            print("\033[91mError: --motif only supported for protein databases (.phr)\033[0m")
            return
        if args.nucleotide_query:
            print("\033[91mError: --motif incompatible with --nucleotide-query\033[0m")
            return
        if not fasta_path or not os.path.exists(fasta_path):
            print("\033[91mError: A valid --fasta-directory path is required with --motif\033[0m")
            return

        #Prepare motif list, allow {basename} filtering
        query_basenames = [os.path.splitext(os.path.basename(f))[0] for f in query_files]
        valid_motifs = []

        for raw_motif in args.motif:
            target_basename = None
            if (('{' in raw_motif and raw_motif.endswith(('}', ']'))) or 
                ('[' in raw_motif and raw_motif.endswith((']', '}')))):
                try:
                    if '{' in raw_motif:
                        motif_str, target_basename = raw_motif.split('{', 1)
                        target_basename = target_basename.rstrip('}]')
                    else:
                        motif_str, target_basename = raw_motif.split('[', 1)
                        target_basename = target_basename.rstrip('}]')

                    motif = motif_str.upper()

                    if not target_basename or target_basename not in query_basenames:
                        print(f"\033[93mWarning: Motif '{motif}' restricted to '{target_basename}', "
                              f"but no query file matched. Skipping\033[0m")
                        continue

                except ValueError:
                    print(f"\033[91mInvalid motif format '{raw_motif}' "
                          f"use MOTIF{{basename}} or MOTIF[basename]\033[0m")
                    continue

            else:
                motif = raw_motif.upper()
                target_basename = None

            if len(motif) < 4 or len(re.findall(r"[^X]", motif)) < 2:
                print(f"\033[91mInvalid motif '{motif}': must have ≥ 4 characters and ≥ 2 non-'X'\033[0m")
                continue

            valid_motifs.append((motif, re.compile(motif.replace("X", "."), re.IGNORECASE), target_basename))

        if not valid_motifs:
            print("\033[91mNo valid motifs provided. Exiting.\033[0m")
            return

        motif_regexes = valid_motifs
        using_motif = True

    #Build BLAST tasks
    db_names, tasks = set(), []
    write_alignment = not args.no_alignment_files
    for query_file_path in query_files:
        query_file_basename = os.path.splitext(os.path.basename(query_file_path))[0]
        for db_file in db_basenames:
            basename = os.path.basename(db_file)
            db_type = db_type_map.get(basename)
            if not db_type:
                print(f"\033[91mError: Could not determine DB type for {basename}\033[0m")
                continue

            blast = "blastn" if db_type == "nucleotide" and args.nucleotide_query else (
                    "tblastn" if db_type == "nucleotide" else "blastp")
            if args.nucleotide_query and db_type == "protein":
                print(f"\033[91mError: --nucleotide-query not valid for protein DB '{db_file}'\033[0m")
                continue

            output_file = os.path.join(results_output_dir, f"{basename}_{query_file_basename}_results.txt")
            alignment_file = os.path.join(results_output_dir, f"{basename}_{query_file_basename}_alignment.txt")

            tasks.append((blast, db_file, query_file_path, output_file, alignment_file,
                          evalue_threshold, basename, query_file_basename, args.min_seq_len,
                          write_alignment))
            db_names.add((query_file_basename, basename))

    progress_arg = args.progress

    progress_mode = progress_arg if progress_arg is not None else "none"

    blast_progress = ProgressHandler(total=len(tasks), prefix=f"{blast}", mode=progress_mode)

    with ProcessPoolExecutor(max_workers=threads) as executor:
        futures = [executor.submit(execute_blast_query, t) for t in tasks]
        for future, task in zip(futures, tasks):
            output_file, db_name, query_file_basename = future.result()
            if progress_mode == 'verbose':
                _, db_path, query_file_path, *_ = task
                print(f"Processed {os.path.basename(query_file_path)} for {os.path.basename(db_path)}")
            blast_progress.update(1)
        blast_progress.finish()

    fieldnames = ['qseqid', 'sseqid', 'pident', 'length', 'mismatch', 'gapopen',
                  'qstart', 'qend', 'sstart', 'send', 'evalue', 'bitscore', 'qlen', 'sframe']
    combined_results = []
    for output_file in os.listdir(results_output_dir):
        if output_file.endswith("_results.txt"):
            path = os.path.join(results_output_dir, output_file)
            with open(path, 'r') as f:
                reader = csv.reader(f, delimiter='\t')
                for row in reader:
                    if len(row) == len(fieldnames):
                        task_info = next((task[6:8] for task in tasks if task[3] == path), (None, None))
                        combined_results.append(row + list(task_info))

    if not combined_results:
        print("\033[91mNo BLAST results found.\033[0m")
        return

    df = pd.DataFrame(combined_results, columns=fieldnames + ['database', 'query_file_name'])
    df[['qstart', 'qend', 'qlen', 'pident', 'evalue', 'sframe']] = (
        df[['qstart', 'qend', 'qlen', 'pident', 'evalue', 'sframe']].apply(pd.to_numeric, errors='coerce')
    )
    df['query_coverage'] = ((df['qend'] - df['qstart']) / df['qlen'] * 100).round(2)

    df = df[['qseqid', 'sseqid', 'database', 'query_file_name', 'pident', 'query_coverage',
             'evalue', 'bitscore', 'length', 'mismatch', 'gapopen', 'qstart', 'qend',
             'sstart', 'send', 'qlen', 'sframe']]
    df.to_csv(os.path.join(results_output_dir, "all_results.csv"), index=False)
    print(f"\n\033[92mSaved all_results.csv\033[0m")

    filtered_df = df[(df['evalue'] <= evalue_threshold) &
                     (df['pident'] >= perc_identity_threshold) &
                     (df['query_coverage'] >= query_coverage_threshold)]

    if args.report_strongest_matches:
        filtered_df.groupby(['database', 'query_file_name']).first().reset_index().to_csv(
            os.path.join(results_output_dir, "filtered_results.csv"), index=False)
    else:
        filtered_df.to_csv(os.path.join(results_output_dir, "all_filtered_results.csv"), index=False)

    if not args.keep_temp_files:
        for file in os.listdir(results_output_dir):
            if file.endswith("_results.txt"):
                os.remove(os.path.join(results_output_dir, file))

    motif_df = pd.DataFrame()
    if using_motif:
        print(f"\033[95mSearching for motifs: {' '.join(m[0] for m in motif_regexes)}\033[0m")
        motif_df = run_motif_search(
            df, 
            fasta_path, 
            motif_regexes, 
            results_output_dir, 
            threads, 
            args.progress,
            keep_temp=getattr(args, 'keep_temp_files', False),
            temp_dir_base=getattr(args, 'temp_dir', None)
        )

        #Handle restricted-target warnings only if hits exist
        if not motif_df.empty:
            restricted_targets = {target for _, _, target in motif_regexes if target}
            seen_queries = set(motif_df['query'].unique())
            for target in restricted_targets:
                if target not in seen_queries:
                    msg = f"Warning: Motif restricted to '{target}' had no hits in any query results."
                    print(f"\033[93m{msg}\033[0m")
                    logger.warning(msg)

    if using_motif and not motif_df.empty and args.motif_fasta_out:
        export_motif_fasta(
            motif_df, 
            results_output_dir, 
            fasta_path=fasta_path,
            motif_only=args.motif_only,
            keep_temp=getattr(args, 'keep_temp_files', False),
            temp_dir_base=getattr(args, 'temp_dir', None),
            logger=logger
            )

    if args.visualize:
        from visualize import run_visualization
        run_visualization(filtered_df, args)
        if using_motif and not motif_df.empty:
            from visualize import run_sequence_logo
            run_sequence_logo(motif_df, args)

    cleanup_temp_dir(temp_dir, keep=getattr(args, 'keep_temp_files', False), logger=logger)

    end_time = datetime.now()
    print(f"Query completed at {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
    logger.info(f"Total runtime: {str(end_time - start_time)}")
    print(f"Total runtime: {str(end_time - start_time)}")
    return filtered_df
